from odoo import models, fields, api
class absence_views(models.Model):
    _description = 'absence_views'
    _name = 'absence_views'
    reason = fields.Text()
    name=fields.Char(string='Name',required=True)
    user = fields.Many2one('res.users', string='user')
    date_from = fields.Date()
    date_to = fields.Date()
    state=fields.Selection([
        ('draft', 'Draft'),
        ('submit','Submit'),
        ('rejected','Rejected'),

    ],readonly=True,string='Status',default='draft')

    def action_submit(self):
        for rec in self:
            rec.state='submit'




    def action_rejected(self):
         self.state='rejected'